from .usecase import UsecaseKelas

class HandlerKelas:

    def getAll():
        return UsecaseKelas.getAll()

    def getSingle(request):
        kode = request.args.get("kode")
        return UsecaseKelas.getSingle(kode)

    def post(request):
        data = request.json
        nama_kelas = data.get("nama_kelas")
        matakuliah_kode = data.get("matakuliah_kode")
        return UsecaseKelas.post(nama_kelas, matakuliah_kode)

    def update(request):
        data = request.json
        kode = data.get("kode")
        nama_kelas = data.get("nama_kelas")
        matakuliah_kode = data.get("matakuliah_kode")
        return UsecaseKelas.update(kode, nama_kelas, matakuliah_kode)

    def delete(request):
        data = request.json
        kode = data.get("kode")
        return UsecaseKelas.delete(kode)
