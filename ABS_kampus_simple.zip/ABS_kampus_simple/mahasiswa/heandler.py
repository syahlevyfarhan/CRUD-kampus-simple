from .usecase import Usecase

class HandlerMahasiswa():

    # GET ALL
    def getAll():
        return Usecase.getAll()

    # GET SINGLE (pakai query param)
    def getSingle(request):
        kode = request.args.get('kode')
        return Usecase.getSingle(kode)

    # POST / Tambah Data
    def post(request):
        data = request.json
        nama = data.get("nama")
        nim = data.get("nim")
        ket = data.get("ket")

        return Usecase.post(nama, nim, ket)

    # UPDATE / Ubah Data
    def update(request):
        data = request.json
        kode = data.get("kode")
        nama = data.get("nama")
        nim = data.get("nim")
        ket = data.get("ket")

        return Usecase.update(kode, nama, nim, ket)

    # DELETE
    def delete(request):
        data = request.json
        kode = data.get("kode")

        return Usecase.delete(kode)
