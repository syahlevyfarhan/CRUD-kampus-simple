from .usecase import UsecaseMatakuliah

class HandlerMatakuliah:

    def getAll():
        return UsecaseMatakuliah.getAll()

    def getSingle(request):
        kode = request.args.get("kode")
        return UsecaseMatakuliah.getSingle(kode)

    def post(request):
        data = request.json
        nama = data.get("nama")
        sks = data.get("sks")
        return UsecaseMatakuliah.post(nama, sks)

    def update(request):
        data = request.json
        kode = data.get("kode")
        nama = data.get("nama")
        sks = data.get("sks")
        return UsecaseMatakuliah.update(kode, nama, sks)

    def delete(request):
        data = request.json
        kode = data.get("kode")
        return UsecaseMatakuliah.delete(kode)
